Diese Dateien werden editiert mit 

 - c:\tool\common\Python\Lib\site-packages\PySide2\designer.exe
 
 
 und dann per d:\99_Dev\studcar_git\40_System\RTEgen_light\40_Implementation\work\gui\makeUI.py
 
 die Python Klassen ohne Inhalt erzeugt