#Path: asw/{{name}}
{% extends "h_base.h" %}
{% block content %}

{{ macros.descrBlock(data) }}
DeclareTask({{name}});

{% endblock %}
