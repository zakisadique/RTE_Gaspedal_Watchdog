#Path: rte/{{name}}
/* left empty on purpose, everything is defined in the header*/
