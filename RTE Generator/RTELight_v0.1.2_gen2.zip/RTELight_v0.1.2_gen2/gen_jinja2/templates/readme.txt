Hints on formatiing and whitespaces in Jinja templates/#whitespace-control
==========================================================================

https://jinja.palletsprojects.com/en/2.11.x/templates/#whitespace-control